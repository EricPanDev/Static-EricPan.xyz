# Change Working Directory
import os;
try: os.chdir(os.path.dirname(os.path.abspath(__file__)))
except Exception: pass

# Import Modules
from Modules.CookieAuth import *
from Modules.HTTPServer import *
from Modules.Hash import *

class HTTPRequestHandler(HTTP_Handler):
    def do_PUT(self):
        cookies = SimpleCookie(self.headers.get('Cookie'))
        if "authorization" in cookies:
            if validate_cookie(cookies["authorization"]) == True:
                filename = unquote("file-" + str(os.path.basename(self.path)))
                if os.path.exists("CDN_Storage/CDN/CDN/" + filename):
                    complete=0
                    _temp = 1
                    while not complete:
                        if not os.path.exists(f"{filename}@{_temp}"):
                            complete = 1
                        else:
                            _temp += 1
                    file_length = int(self.headers['Content-Length'])
                    read = 0
                    with open(f"CDN_Storage/CDN/CDN/{filename}@{_temp}", 'wb+') as output_file:
                        while read < file_length:
                            new_read = self.rfile.read(min(66556, file_length - read))
                            read += len(new_read)
                            output_file.write(new_read)
                    saved_as = f"{filename}@{_temp}"

                else:
                    file_length = int(self.headers['Content-Length'])
                    read = 0
                    with open("CDN_Storage/CDN/CDN/" + filename, 'wb+') as output_file:
                        while read < file_length:
                            new_read = self.rfile.read(min(66556, file_length - read))
                            read += len(new_read)
                            output_file.write(new_read)
                    saved_as = filename
                file_hash = hash_2(10)
                with open("CDN_Storage/map.txt", "a") as map:
                    map.write(f"{file_hash}|||{filename[5:]}|||{saved_as}\n")
                self.send_response(200)
                self.send_header("content-type", "text/html")
                self.end_headers()
                self.wfile.write(bytes(file_hash, "utf-8"))
                
            else:
                # Unauthorized request, close connection
                self.close_connection()
        else:
            # No Authorization Cookie, close connection
            self.close_connection()

    

    def do_GET(self):
        # Load user cookies
        cookies = SimpleCookie(self.headers.get('Cookie'))
        if "login" in self.path and "?" in self.path:
            i = self.path.index ( "?" ) + 1
            params = dict ( [ tuple ( p.split("=") ) for p in self.path[i:].split ( "&" ) ] )
            if "user" in params and "pass" in params:
                # Valid Login Attempt, Continue Serving
                if validate_cookie(cookies["authorization"]) == True:
                    # Login Successful, Allow Access
                    pass
                else:
                    # Unsuccessful Login, Close Connection
                    self.close_connection()
            else:
                # Malformed Login Attempt, Close Connection
                self.close_connection()
        elif self.path not in ["/", ""]:
            requested_hash, requested_download_name, requested_stored_location = [None, None, None]
            # User requesting file
            with open("CDN_Storage/map.txt") as mapfile:
                for line in mapfile:
                    if line.split("|||")[0] == unquote(self.path[1:]):
                        requested_hash, requested_download_name, requested_stored_location = line.split("|||")
            mapfile.close()
            if requested_stored_location != None:
                requested_stored_location = requested_stored_location.replace("\n", "")
                with open(f"CDN_Storage/CDN/CDN/{requested_stored_location}", "rb") as fn:
                    self.send_response(200)
                    self.send_header("Content-type", "application/octet-stream")
                    self.send_header("Content-Disposition", 'attachment; filename="%s"' % (requested_download_name))
                    self.send_header("Content-Length", str(os.fstat(fn.fileno()).st_size))
                    self.end_headers()
                    shutil.copyfileobj(fn, self.wfile)
                    fn.close()
            else:
                self.send_response(404, "Not Found")
                self.send_header("404", "Not Found")

        else:
            if "authorization" in cookies:
                # User already logged in, load upload page
                if validate_cookie(cookies["authorization"]) == True:
                    self.send_response(200)
                    self.send_header("content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(bytes(f"""{open("Static/upload.html").read()}""", "utf-8"))
                else:
                    # Invalid Cookie, redirect to login page
                    self.send_response(200)
                    self.send_header("content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(bytes(f"""{open("Static/login.html").read()}""", "utf-8"))
            else:
                # User not logged in, redirect to login page
                self.send_response(200)
                self.send_header("content-type", "text/html")
                self.end_headers()
                self.wfile.write(bytes(f"""{open("Static/login.html").read()}""", "utf-8"))

run(host=("127.0.0.1", 8000), handler=HTTPRequestHandler, name=__name__)