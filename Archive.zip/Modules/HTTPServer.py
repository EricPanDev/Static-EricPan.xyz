from http.server import HTTPServer
from http.server import SimpleHTTPRequestHandler as HTTP_Handler
from urllib.parse import unquote
def serve_forever(Server):
    try: Server.serve_forever()
    except KeyboardInterrupt: pass

def run(host, handler, name):
    if name == "__main__":
        Server_OBJ = HTTPServer(host, handler)
        try: Server_OBJ.serve_forever()
        except KeyboardInterrupt: pass