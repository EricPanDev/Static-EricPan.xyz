from http.cookies import SimpleCookie
import shutil

def validate_cookie(cookie):
    cookie = cookie.value
    cookie_is_valid = 0
    with open("Modules/auth/valid.txt") as valid_cookies:
        for valid_cookie in valid_cookies:
            if cookie == valid_cookie:
                cookie_is_valid = 1
        valid_cookies.close()
    if cookie_is_valid:
        # print(f"cookie {cookie} is valid")
        return True
    else:
        # print(f"cookie {cookie} is not valid")
        return False