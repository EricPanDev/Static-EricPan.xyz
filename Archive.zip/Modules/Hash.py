import random, string

def hash_2(length):
    return ''.join(random.choice(string.ascii_lowercase) for i in range(length))